<?php 
$page="projects";
include("header.php")?>
<section id="content">
<div class ="container projects">
<div class="col-xs-5"><img src="img/project-1.jpg" class="img-responsive pro-image"></div>
<div class="col-xs-7">
<h3 class="pro-title">Project 1</h1>
<p class="pro-description">Description</p>
</div>
</div>
<div class ="container projects">
<div class="col-xs-5"><img src="img/project-2.jpg" class="img-responsive pro-image"></div>
<div class="col-xs-7">
<h3 class="pro-title">Project 2</h1>
<p class="pro-description">Description</p>
</div>
</div>
<div class ="container projects">
<div class="col-xs-5"><img src="img/project-3.jpg" class="img-responsive pro-image"></div>
<div class="col-xs-7">
<h3 class="pro-title">Project 3</h1>
<p class="pro-description">Description</p>
</div>
</div>
</section>
<?php include("footer.php")?>