<?php 
$page="home";
include("header.php")?><section id="content">
<div class ="container">
<div class="categories">
<div class="row">
<div class="cat-thumb col-xs-3">
<img src="img/building-constructions.png">
<div class="title">Building Constructions</div>
</div>
<div class="cat-thumb col-xs-3">
<img src="img/interiors-and-modular-kitchens.jpg" >
<div class="title">Interiors & Modular Kitchens</div>
</div>
<div class="cat-thumb col-xs-3">
<img src="img/consulting-engineers.jpg" >
<div class="title">Consulting Engineers</div>
</div>
<div class="cat-thumb col-xs-3">
<img src="img/water-proofing.jpg" >
<div class="title">Water Proofing</div>
</div>
</div>
<div class="about-us">
<p>JKS are committed to provided our clients with the excellence of the highest qualities through the best of class performance and efficiency. We make sure to understand our client objectives and together find the best solution for client's projects, while always being respectful of client's budget. Our experiences, technologies and preserverance enable us to overcome challenges and deliver value.</p>
<p>We use best-in-class materials to ensure that the most hardworking space in the house is designed for just that hardwork. JKS is skilled at kitchen installations-from ensuring that doors align perfectly, to securely fixing the worktops, each until will be fitted with an exacting attention to detail. So you are guaranteed a kitchen that is absolutely perfect. Whatever you're moving into a new home or looking to renovate an old kitchen, you'll find that our prices are perfect for different budgets</p>
<p>We offers various waterproofing systems such crystalline waterproofing, acrylic polymers, transparent, waterproofing coatings, etc.</p>
</div>
</div>
</div>
</section>
<?php include("footer.php")?>