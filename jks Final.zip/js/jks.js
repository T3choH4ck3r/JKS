$(document).ready(function(){
    $("li a#men1").hover(function(){
        $("span#men1").removeclass("hide");
        });
});