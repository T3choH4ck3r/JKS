<footer>
<div class="container">

<div class="footer-area">
<div class="footer-content">
<div class="row">
<?php
if($page=="home")
{
?>
<div class="flogo col-xs-4">
<img src="img/footer-logo.jpg" class="img=responsive">
</div>
<div class="fdetails col-xs-8">
<div class="faddress col-xs-12">
NO: 11, Suba Shri Nagar, Veppampattu, Thiruvallur - 602024 
</div>
<div class="fphone col-xs-12">
Phone: +91 87548 41161
</div>
</div>
</div>
</div>
<?php }?>
<div class="footer-line">
2016 JKS. All Rights Reserved
</div>
</div>
</footer>
</section>
</body>
</html>